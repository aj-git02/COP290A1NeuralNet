#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <string>
#include <cassert>
#include "dnn_weights.h"
#include<algorithm>
#include "2020CS10318.h"
using namespace std;

int main(int argc,char *argv[]){
    
    if(argc != 3){ // when this command is to be called we require 6 components including the ./yourcode.out
        cerr<<"Error : Not enough inputs declared in the command\n";
        cout<<"To know about the valid command type 'help' or type 'exit' to exit this\n";
     	string a;
     	cin >> a;
     	if(a == "help"){
     		cout<<"Following is a recongnisable command\n";
            cout<<"./yourcode.out audiosamplefile outputfile \n";
        }
        else{
     		cout<<"Exiting.....\n";
     	}
        return 0;
    }
    
    pred_t* pred;

    pred=libaudioAPI(argv[1],pred);

    string features[12] = {"silence","unknown","yes","no","up","down","left","right","on","off","stop","go"};

    //asserting that mat multiplication and addition will be valid
    // assert(input_matrix[0].size()==weight_matrix.size());
    // assert(output_matrix.size()==bias_matrix.size());
    // assert(output_matrix[0].size()==bias_matrix[0].size());
    
    string file1=string(argv[2]);
    ofstream destination;
    destination.open(file1,std::ios_base::app);
    if (!destination.is_open()) { 
        cerr<<"File could not be opened"<<"\n";
        return 0;
    }

    destination << string(argv[1]) << " " << features[pred[0].label] << " " << features[pred[1].label] << " " << features[pred[2].label] << " ";
    destination << pred[0].prob << " " << pred[1].prob << " " << pred[2].prob << "\n"; 

    destination.close();
    
    // if (false){ // if any other argument is given, a help block is displayed to the user
    // 	cerr<<"Error : The given command is not recongnisable by the program\n";
   
    // }
    return 0;
}